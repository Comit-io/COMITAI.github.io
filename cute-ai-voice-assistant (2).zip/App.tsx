
import React, { useState, useCallback, useEffect } from 'react';
import { Screen, Message } from './types';
import VoiceScreen from './components/VoiceScreen';
import ChatScreen from './components/ChatScreen';
import HomeScreen from './components/HomeScreen';
import AppDevScreen from './components/AppDevScreen';
import PromptMakerScreen from './components/PromptMakerScreen';
import ToolsScreen from './components/ToolsScreen';
import DonationScreen from './components/PaymentScreen';
import VoiceGeneratorScreen from './components/VoiceGeneratorScreen';
import ImageGeneratorScreen from './components/ImageGeneratorScreen';
import AdminScreen from './components/AdminScreen';
import SettingsScreen from './components/SettingsScreen';
import LoginScreen from './components/LoginScreen';
import RegisterScreen from './components/RegisterScreen';
import ProfileScreen from './components/ProfileScreen';
import PromptLibraryScreen from './components/PromptLibraryScreen';
import DubbingScreen from './components/DubbingScreen';
import TermuxGuideScreen from './components/TermuxGuideScreen';
import ErrorBoundary from './components/ErrorBoundary';
import { auth } from './services/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { MegaphoneIcon, WarningIcon, CloudUploadIcon, RocketIcon } from './components/icons';

const CURRENT_APP_VERSION = "2.2.0";

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.Voice);
  const [messages, setMessages] = useState<Message[]>([]);
  const initialPromptRef = React.useRef<string>('');
  
  // Admin Controlled State
  const [showAds, setShowAds] = useState(true);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [globalNotice, setGlobalNotice] = useState<string | null>(null);
  
  // Update System State
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [updateInfo, setUpdateInfo] = useState({ version: '', notes: '', force: false });

  // Load Admin Settings
  useEffect(() => {
      const loadAdminConfig = () => {
          const loadedSettings = localStorage.getItem('comet_admin_settings');
          if (loadedSettings) {
              const config = JSON.parse(loadedSettings);
              setShowAds(config.adsEnabled ?? true);
              setMaintenanceMode(config.system?.maintenanceMode ?? false);
              
              // Handle Global Notice
              if (config.system?.showNotice && config.system?.noticeText) {
                  setGlobalNotice(config.system.noticeText);
              } else {
                  setGlobalNotice(null);
              }

              // Handle Updates
              if (config.system?.latestVersion && config.system?.latestVersion !== CURRENT_APP_VERSION) {
                  setUpdateInfo({
                      version: config.system.latestVersion,
                      notes: config.system.updateNotes || 'General bug fixes and performance improvements.',
                      force: config.system.forceUpdate || false
                  });
                  setShowUpdateModal(true);
              }
          }
      };
      
      loadAdminConfig();
      // Listen for storage changes in case admin updates in another tab (optional but good practice)
      window.addEventListener('storage', loadAdminConfig);
      return () => window.removeEventListener('storage', loadAdminConfig);
  }, [currentScreen]); // Re-check on screen change to apply immediate effects

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
        if (user) {
             setCurrentScreen((prev) => {
                // Redirect to Home if on auth screens after login
                if (prev === Screen.Login || prev === Screen.Register) {
                    return Screen.Home;
                }
                return prev;
             });
        }
    });
    return () => unsubscribe();
  }, []);

  const navigateTo = useCallback((screen: Screen, initialPrompt?: string) => {
    if (screen === Screen.Chat && initialPrompt) {
        initialPromptRef.current = initialPrompt;
        setMessages([]); 
    }
    setCurrentScreen(screen);
  }, []);
  
  const startNewChat = useCallback((messages: Message[]) => {
    setMessages(messages);
    setCurrentScreen(Screen.Chat);
  }, []);

  const handleUpdateApp = () => {
      // Simulation of app update
      alert("Downloading updates... The app will reload shortly.");
      setTimeout(() => {
          window.location.reload();
      }, 2000);
  };

  const renderScreen = () => {
    // Maintenance Mode Logic: Block everything except Admin/Settings
    if (maintenanceMode && currentScreen !== Screen.Admin && currentScreen !== Screen.Settings) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
                 <div className="glass-panel p-8 rounded-2xl flex flex-col items-center max-w-sm">
                    <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mb-6 animate-pulse border border-red-500/30">
                        <WarningIcon className="w-10 h-10 text-red-400" />
                    </div>
                    <h1 className="text-2xl font-bold text-white mb-2">System Maintenance</h1>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                        COMET AI is currently undergoing scheduled updates to improve performance. Please check back later.
                    </p>
                    <button 
                        onClick={() => navigateTo(Screen.Settings)} 
                        className="text-xs text-gray-500 hover:text-white underline transition-colors"
                    >
                        Admin Access
                    </button>
                 </div>
            </div>
        );
    }

    switch (currentScreen) {
      case Screen.Home:
        return <HomeScreen navigateTo={navigateTo} />;
      case Screen.Voice:
        return <VoiceScreen navigateTo={navigateTo} startNewChat={startNewChat} />;
      case Screen.Chat:
        return <ChatScreen 
                    messages={messages} 
                    setMessages={setMessages} 
                    navigateTo={navigateTo} 
                    initialPrompt={initialPromptRef.current} 
                />;
      case Screen.AppDev:
        return <AppDevScreen navigateTo={navigateTo} />;
      case Screen.PromptMaker:
        return <PromptMakerScreen navigateTo={navigateTo} />;
      case Screen.Tools:
        return <ToolsScreen navigateTo={navigateTo} />;
      case Screen.Donation:
        return <DonationScreen navigateTo={navigateTo} />;
      case Screen.VoiceGenerator:
        return <VoiceGeneratorScreen navigateTo={navigateTo} />;
      case Screen.ImageGenerator:
        return <ImageGeneratorScreen navigateTo={navigateTo} />;
      case Screen.Admin:
        return <AdminScreen navigateTo={navigateTo} />;
      case Screen.Settings:
        return <SettingsScreen navigateTo={navigateTo} />;
      case Screen.Login:
        return <LoginScreen navigateTo={navigateTo} />;
      case Screen.Register:
        return <RegisterScreen navigateTo={navigateTo} />;
      case Screen.Profile:
        return <ProfileScreen navigateTo={navigateTo} />;
      case Screen.PromptLibrary:
        return <PromptLibraryScreen navigateTo={navigateTo} />;
      case Screen.Dubbing:
        return <DubbingScreen navigateTo={navigateTo} />;
      case Screen.TermuxGuide:
        return <TermuxGuideScreen navigateTo={navigateTo} />;
      default:
        return <HomeScreen navigateTo={navigateTo} />;
    }
  };

  return (
    <div className="h-screen w-screen font-sans overflow-hidden flex flex-col text-white">
      <div className="relative flex-grow w-full max-w-md mx-auto overflow-hidden flex flex-col shadow-2xl">
        
        {/* Global Notice Banner */}
        {globalNotice && (
            <div className="bg-gradient-to-r from-cyan-600/90 to-blue-600/90 backdrop-blur-md text-white text-[10px] font-bold py-2 px-4 text-center flex items-center justify-center gap-2 z-50 shrink-0 uppercase tracking-wider border-b border-white/10">
                <MegaphoneIcon className="w-3.5 h-3.5 animate-bounce" />
                <span>{globalNotice}</span>
            </div>
        )}

        {/* Main Content Area */}
        <div className="relative flex-grow w-full z-10 overflow-hidden flex flex-col">
          <ErrorBoundary>
            {renderScreen()}
          </ErrorBoundary>
        </div>

        {/* Update Modal Overlay */}
        {showUpdateModal && currentScreen !== Screen.Admin && (
            <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
                <div className="glass-panel rounded-3xl p-6 w-full max-w-sm shadow-[0_0_50px_rgba(139,92,246,0.3)] relative overflow-hidden">
                    {/* Background decoration */}
                    <div className="absolute -top-20 -right-20 w-40 h-40 bg-purple-500/30 rounded-full blur-[60px]"></div>
                    
                    <div className="text-center relative z-10">
                        <div className="w-16 h-16 bg-gradient-to-tr from-purple-600 to-blue-600 rounded-2xl rotate-3 flex items-center justify-center mx-auto mb-4 shadow-lg ring-4 ring-white/10">
                            <RocketIcon className="w-8 h-8 text-white -rotate-3" />
                        </div>
                        <h2 className="text-2xl font-bold text-white tracking-tight">New Update Available</h2>
                        <p className="text-cyan-400 font-mono text-xs mt-1 bg-cyan-500/10 px-2 py-0.5 rounded-full inline-block">v{updateInfo.version}</p>
                        
                        <div className="my-6 text-left bg-black/30 p-4 rounded-xl border border-white/5 max-h-32 overflow-y-auto custom-scrollbar">
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-2">Change Log</p>
                            <p className="text-sm text-gray-200 leading-relaxed">{updateInfo.notes}</p>
                        </div>

                        <div className="space-y-3">
                            <button 
                                onClick={handleUpdateApp}
                                className="w-full py-3.5 bg-white text-black hover:bg-gray-200 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
                            >
                                <CloudUploadIcon className="w-5 h-5" /> Update Now
                            </button>
                            
                            {!updateInfo.force && (
                                <button 
                                    onClick={() => setShowUpdateModal(false)}
                                    className="w-full py-2 text-xs text-gray-400 hover:text-white transition-colors"
                                >
                                    Remind Me Later
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default App;
