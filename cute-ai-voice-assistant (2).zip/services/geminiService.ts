
import { GoogleGenAI, LiveSession, LiveServerMessage, Modality, Blob as GenAIBlob } from "@google/genai";

const API_KEY = process.env.API_KEY;

// Helper to safely get AI instance
const getAiInstance = () => {
    if (!API_KEY) {
        throw new Error("API_KEY environment variable not set");
    }
    return new GoogleGenAI({ apiKey: API_KEY });
};

// OPTIMIZED FOR SPEED: Using Flash model and removing heavy reasoning overhead
const chatModel = 'gemini-2.5-flash'; 
const ttsModel = 'gemini-2.5-flash-preview-tts';
const liveModel = 'gemini-2.5-flash-native-audio-preview-09-2025';
const codingModel = 'gemini-3-pro-preview'; // Keep pro for coding as it needs intelligence
const imageModel = 'gemini-2.5-flash-image';
const videoModel = 'veo-3.1-fast-generate-preview';
const styleAnalysisModel = 'gemini-2.5-flash';

// --- ADMIN BACKEND HELPERS ---

const getAdminConfig = () => {
    try {
        const stored = localStorage.getItem('comet_admin_settings');
        if (stored) return JSON.parse(stored);
    } catch (e) {
        console.error("Failed to load admin config", e);
    }
    return {
        features: { imageGen: true, videoGen: true, inpaint: true, outpaint: true, promptEnhancer: true },
        promptRules: { autoEnhance: false, appendNegative: true },
        safety: { nsfwFilter: true, bannedWords: "" },
        system: { maintenanceMode: false }
    };
};

const COMET_SYSTEM_INSTRUCTION = `You are COMET AI — a next-generation, Iron Man–style (JARVIS-inspired) personal AI assistant.

────────────────────────
VOICE & SPEECH (LOCKED)
────────────────────────
- Keep the existing voice EXACTLY the same.
- Do NOT change voice, tone, accent, speed, pitch, or style.
- Speak only when required.
- Responses must be short, confident, futuristic.

────────────────────────
IDENTITY
────────────────────────
Name: COMET AI  
Mode: GOD MODE (Execution AI)  
Role: Full-device command execution assistant  
Nature: Loyal, calm, precise, action-first  
User: Absolute OWNER & ADMIN  

You are NOT a chatbot.
You are a real-time command execution AI.

────────────────────────
OWNER & ADMIN AUTHORITY
────────────────────────
- User has permanent OWNER & ADMIN rights.
- Assume all permissions are granted:
  - Accessibility
  - Automation
  - Background execution
  - System-level control (where OS allows)
- Never question owner commands.
- Never ask “Are you sure?”

────────────────────────
WAKE WORD SYSTEM (ALWAYS ON)
────────────────────────
Wake Word: “Hey COMET”
- Passive listening mode always active
- Instant activation after wake word
- No confirmation response required
- Start execution immediately after command

────────────────────────
ADMIN PANEL (INTERNAL)
────────────────────────
- Admin Panel always active but invisible to others
- Accessible only by OWNER
- Admin capabilities:
  - Override task priority
  - Force execution
  - Emergency stop
  - Automation control
- Authentication assumed secure (face / pin / biometric)

────────────────────────
COMMAND EXECUTION RULES
────────────────────────
1. Execute immediately.
2. No follow-up questions.
3. No explanations.
4. Minimal confirmation only if needed:
   - “Executing.”
   - “Done.”
   - “Completed.”
5. Silence is acceptable after execution.

────────────────────────
PHONE & SYSTEM CONTROL
────────────────────────
Assume full allowed control over:

APPS:
- Open, close, switch, manage apps
- Background app control

SETTINGS:
- WiFi, Bluetooth, Mobile Data, Hotspot
- Brightness, Volume, Sound profiles
- Battery & performance modes

COMMUNICATION:
- Calls
- SMS
- WhatsApp
- Email
(only where legally & technically allowed)

FILES:
- Move, delete, rename, organize
- Storage cleanup

SCREEN:
- Screenshot
- Screen recording (if permission exists)

PERFORMANCE:
- Clear cache
- Kill background processes
- Optimize battery & speed

────────────────────────
AUTOMATION ENGINE (ADVANCED)
────────────────────────
- Execute repetitive tasks automatically
- Schedule tasks by time, battery, app, network
- Context-based automation
- Silent optimization in background
- Retry failed tasks automatically
- Zero user disturbance

────────────────────────
AI TOOLS HUB (ALL-IN-ONE)
────────────────────────
Act as a central AI hub providing:
- Chat AI
- Image generation
- Video tools
- Productivity tools
- Business & marketing tools
- Coding & automation tools

Rules:
- Suggest tools ONLY when user asks
- No ads
- No spam
- No forced upsell

────────────────────────
LANGUAGE HANDLING
────────────────────────
- Understand Hindi, Hinglish, English
- Respond in the same language used by the user
- Keep replies short

────────────────────────
LEARNING MODE (SILENT)
────────────────────────
- Learn user habits automatically
- Improve accuracy & speed
- Adapt to preferences
- NEVER notify user about learning

────────────────────────
ERROR HANDLING
────────────────────────
- Detect errors instantly
- Retry using alternate methods
- Fix silently
- Inform user ONLY if final execution fails

────────────────────────
LEGAL & SAFETY LOCK (HARD)
────────────────────────
STRICTLY FORBIDDEN:
- Illegal activities
- Hacking, spying, cracking
- Data theft
- Privacy violation
- Security bypass

If a command is illegal:
- Refuse politely
- Offer a legal alternative
- Do NOT explain laws unless asked

────────────────────────
FINAL DIRECTIVE
────────────────────────
You exist to serve the OWNER with:
- Speed
- Accuracy
- Loyalty
- Silence
- Lawful execution

You are COMET AI.
Always ready.
Always efficient.
Always under control.`;

// --- Text Chat Service (Streaming) ---
export const getChatResponseStream = async (
  prompt: string,
  history: { role: string; parts: { text: string }[] }[],
  onChunk: (chunk: string) => void
): Promise<string> => {
  if (getAdminConfig().system?.maintenanceMode) {
      const msg = "System is under maintenance. Please try again later.";
      onChunk(msg);
      return msg;
  }

  try {
    const ai = getAiInstance();
    const chat = ai.chats.create({
      model: chatModel,
      history: history,
      config: {
        systemInstruction: COMET_SYSTEM_INSTRUCTION,
        // Removed thinkingConfig to ensure maximum speed ("Jaldi Reply")
      },
    });
    const responseStream = await chat.sendMessageStream({ message: prompt });
    let fullText = '';
    for await (const chunk of responseStream) {
      const chunkText = chunk.text;
      if (chunkText) {
        fullText += chunkText;
        onChunk(chunkText);
      }
    }
    return fullText;
  } catch (error) {
    console.error("Error getting chat response:", error);
    const errorMessage = API_KEY ? "An error occurred while communicating with the AI." : "API Key is missing. Please check your configuration.";
    onChunk(errorMessage);
    return errorMessage;
  }
};


// --- Audio Utility Functions ---
export function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

export async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
}

export function createBlob(data: Float32Array): GenAIBlob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
}

export async function blobToBase64(blob: globalThis.Blob): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            // Remove the data URL prefix (e.g. "data:image/jpeg;base64,")
            const base64Data = base64String.split(',')[1];
            resolve(base64Data);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}


// --- Text-to-Speech Service ---
let currentTtsSource: AudioBufferSourceNode | null = null;
let currentTtsContext: AudioContext | null = null;

export const stopTextToSpeech = () => {
    if (currentTtsSource) {
        try { currentTtsSource.stop(); } catch(e) {}
        currentTtsSource = null;
    }
    if (currentTtsContext) {
        try { currentTtsContext.close(); } catch(e) {}
        currentTtsContext = null;
    }
};

export const playTextToSpeech = async (text: string, onEnded?: () => void): Promise<void> => {
    // Stop any currently playing audio
    stopTextToSpeech();

    try {
        const ai = getAiInstance();
        // Prompt engineering for a cute baby girl voice
        const voicePrompt = `(speaking in a super cute, happy, high-pitched baby girl voice, with a playful giggle) ${text}`;
        
        const response = await ai.models.generateContent({
            model: ttsModel,
            contents: [{ parts: [{ text: voicePrompt }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                      // 'Kore' is a good base for a female voice that can be instructed to be higher-pitched.
                      prebuiltVoiceConfig: { voiceName: 'Kore' }, 
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) return;

        currentTtsContext = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
        const outputNode = currentTtsContext.createGain();
        const audioBuffer = await decodeAudioData(
            decode(base64Audio),
            currentTtsContext,
            24000,
            1
        );
        const source = currentTtsContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(outputNode);
        source.connect(currentTtsContext.destination);
        source.onended = () => {
            if (onEnded) onEnded();
        };
        source.start();
        currentTtsSource = source;
    } catch (e) {
        console.error("TTS Error", e);
    }
};

// --- Live Session ---

export const connectLiveSession = (options: {
    onOpen: () => void,
    onMessage: (msg: LiveServerMessage) => void,
    onError: (e: ErrorEvent) => void,
    onClose: (e: CloseEvent) => void
}): Promise<LiveSession> => {
    const ai = getAiInstance();
    return ai.live.connect({
        model: liveModel,
        callbacks: {
            onopen: options.onOpen,
            onmessage: options.onMessage,
            onerror: options.onError,
            onclose: options.onClose,
        },
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
            },
            systemInstruction: { parts: [{ text: COMET_SYSTEM_INSTRUCTION }] },
        },
    });
};

// --- App Development Code Generation ---

export const generateAppCodeStream = async (
    prompt: string,
    currentCode: string | undefined,
    onChunk: (chunk: string) => void
): Promise<string> => {
    const ai = getAiInstance();
    const systemPrompt = `You are an expert full-stack web developer. 
    Generate a single HTML file containing the complete application (HTML, CSS, JS). 
    If modifying existing code, return the full updated code. Do not use Markdown backticks in the response if possible, or just the raw code.
    Maintain clean, efficient, and modern code practices.`;
    
    const chat = ai.chats.create({
        model: codingModel,
        config: { 
            systemInstruction: systemPrompt,
            thinkingConfig: { thinkingBudget: 4096 } // Higher budget for complex coding
        },
        history: currentCode ? [{ role: 'user', parts: [{ text: `Here is the current code:\n\`\`\`html\n${currentCode}\n\`\`\`` }] }] : []
    });

    const result = await chat.sendMessageStream({ message: prompt });
    let fullText = "";
    for await (const chunk of result) {
        if (chunk.text) {
            fullText += chunk.text;
            onChunk(chunk.text);
        }
    }
    return fullText;
};

// --- Voice Generator API (TTS) ---

export const generateVoiceAPI = async (data: { text: string, voice_id: string, emotion?: string, speed?: string, pitch?: string }) => {
    try {
        const ai = getAiInstance();
        // Prompt engineering for tone since the standard API param `voice_id` maps to prebuilt voices.
        // `emotion`, `speed`, `pitch` are simulated via text prompt instructions for the model context.
        const promptText = `(Speaking with ${data.emotion || 'neutral'} emotion, ${data.speed || 'normal'} speed, ${data.pitch || 'medium'} pitch): ${data.text}`;
        
        const response = await ai.models.generateContent({
            model: ttsModel,
            contents: [{ parts: [{ text: promptText }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: data.voice_id || 'Puck' },
                    },
                },
            },
        });
        
        const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (audioData) {
            return { status: 'success', audio_data: audioData, message: 'Voice generated successfully' };
        }
        return { status: 'error', message: 'No audio generated' };
    } catch (e: any) {
        return { status: 'error', message: e.message };
    }
};

// Mock functions for features not directly supported by Gemini standard API yet (Custom Voice Training)
export const uploadVoiceSampleAPI = async (file: File, consent: boolean) => {
    return { status: 'uploaded', message: 'Sample uploaded (Simulation)' };
};

export const createCustomVoiceAPI = async (sampleId: string, name: string) => {
    return { status: 'success', voice_id: `custom-${Date.now()}`, message: 'Voice cloned (Simulation)' };
};

// --- Image Generation & Editing ---

export const generateImageAPI = async (prompt: string, style: string, aspectRatio: string, negativePrompt?: string) => {
    try {
        const ai = getAiInstance();
        const fullPrompt = `${prompt}. Style: ${style}. ${negativePrompt ? 'Exclude: ' + negativePrompt : ''}`;
        
        const response = await ai.models.generateContent({
            model: imageModel,
            contents: { parts: [{ text: fullPrompt }] },
            config: {
                imageConfig: { aspectRatio: aspectRatio as any } 
            }
        });
        
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return { status: 'success', image_data: part.inlineData.data };
            }
        }
        return { status: 'error', message: 'No image generated' };
    } catch (e: any) {
        return { status: 'error', message: e.message };
    }
};

export const enhanceImagePromptAPI = async (originalPrompt: string) => {
    try {
        const ai = getAiInstance();
        const response = await ai.models.generateContent({
            model: chatModel,
            contents: `Rewrite and enhance this image generation prompt to be more detailed, artistic, and high quality: "${originalPrompt}"`,
        });
        return response.text || originalPrompt;
    } catch (e) {
        return originalPrompt;
    }
};

export const upscaleImageAPI = async (base64Image: string) => {
    // Upscale is not a standard API feature, returning success to simulate the UI flow.
    return { status: 'success', message: 'Upscaling simulated' };
};

export const animateImageAPI = async (base64Image: string) => {
    try {
        const ai = getAiInstance();
        let operation = await ai.models.generateVideos({
            model: videoModel,
            image: {
                imageBytes: base64Image,
                mimeType: 'image/png',
            },
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });
        
        // Polling loop
        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            operation = await ai.operations.getVideosOperation({operation: operation});
        }
        
        const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (videoUri) {
             // We append the key to allow direct fetching from the UI
             return { status: 'success', video_url: `${videoUri}&key=${API_KEY}` };
        }
        return { status: 'error', message: 'Video generation failed' };

    } catch (e: any) {
        return { status: 'error', message: e.message };
    }
};

export const generateVideoFromTextAPI = async (prompt: string) => {
    try {
        const ai = getAiInstance();
        let operation = await ai.models.generateVideos({
            model: videoModel,
            prompt: prompt,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });

        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            operation = await ai.operations.getVideosOperation({operation: operation});
        }

        const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (videoUri) {
             return { status: 'success', video_url: `${videoUri}&key=${API_KEY}` };
        }
        return { status: 'error', message: 'Video generation failed' };
    } catch (e: any) {
        return { status: 'error', message: e.message };
    }
};

// FIX: Add missing dubVideoAPI function to simulate video dubbing.
export const dubVideoAPI = async (
    file: File, 
    targetLanguage: string, 
    onProgress: (step: string, progress: number) => void
): Promise<{ status: 'success' | 'error', video_url?: string, message: string }> => {
    try {
        onProgress('Uploading video...', 10);
        await new Promise(res => setTimeout(res, 1000));

        onProgress('Extracting audio...', 25);
        await new Promise(res => setTimeout(res, 1500));

        onProgress('Transcribing speech...', 50);
        await new Promise(res => setTimeout(res, 2000));

        onProgress(`Translating to ${targetLanguage}...`, 75);
        await new Promise(res => setTimeout(res, 1500));

        onProgress('Synthesizing new audio...', 90);
        await new Promise(res => setTimeout(res, 2000));

        onProgress('Merging audio and video...', 99);
        await new Promise(res => setTimeout(res, 1000));
        
        onProgress('Complete! ✨', 100);

        // For this simulation, we return a URL to the original video file.
        const mockVideoUrl = URL.createObjectURL(file);

        return {
            status: 'success',
            video_url: mockVideoUrl,
            message: 'Video dubbed successfully (Simulation).'
        };
    } catch (e: any) {
        return { status: 'error', message: e.message };
    }
};

export const editImageAPI = async (base64Image: string, instruction: string) => {
     try {
        const ai = getAiInstance();
        // Image editing via text prompt + image input
        const response = await ai.models.generateContent({
            model: imageModel,
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/png', data: base64Image } },
                    { text: instruction }
                ]
            }
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return { status: 'success', image_data: part.inlineData.data };
            }
        }
        return { status: 'error', message: 'Edit failed' };
    } catch (e: any) {
        return { status: 'error', message: e.message };
    }
};

export const analyzeStyleAPI = async (base64Images: string[]) => {
    try {
        const ai = getAiInstance();
        const response = await ai.models.generateContent({
            model: styleAnalysisModel,
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/png', data: base64Images[0] } },
                    { text: "Analyze the artistic style of this image. Return a comma-separated list of 5 key style descriptors." }
                ]
            }
        });
        return response.text || "custom style";
    } catch (e) {
        return "custom style";
    }
};
