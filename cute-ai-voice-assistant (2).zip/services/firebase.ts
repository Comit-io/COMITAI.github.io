
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// IMPORTANT: Replace with your app's Firebase project configuration
const firebaseConfig = {
  apiKey: "AIzaSyB...THIS_IS_A_PLACEHOLDER..._API_KEY",
  authDomain: "your-project-id.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:a1b2c3d4e5f6g7h8i9j0"
};

/*
* 🔥 TROUBLESHOOTING GOOGLE SIGN-IN ERRORS 🔥
* Most Google Sign-In errors are due to configuration issues in Firebase and Google Cloud.
* Follow these steps carefully:
*
* 1. ✅ ENABLE GOOGLE SIGN-IN IN FIREBASE:
*    - Go to your Firebase Console -> Authentication -> Sign-in method.
*    - Click on "Google" and enable it.
*    - Make sure a "Project support email" is selected.
*    - Click "Save".
*
* 2. ✅ CONFIGURE OAUTH CONSENT SCREEN IN GOOGLE CLOUD:
*    - Go to Google Cloud Console -> APIs & Services -> OAuth consent screen.
*    - Make sure your app name, support email, and developer contact are filled out.
*    - Save the settings. You usually don't need to submit for verification for testing.
*
* 3. ✅ CHECK AUTHORIZED DOMAINS IN FIREBASE:
*    - Go to your Firebase Console -> Authentication -> Settings.
*    - Under "Authorized domains", make sure your hosting domain is listed.
*    - If you are testing locally, `localhost` should be there by default.
*
* 4. ✅ CHECK OAUTH 2.0 CLIENT ID IN GOOGLE CLOUD:
*    - Go to Google Cloud Console -> APIs & Services -> Credentials.
*    - Find the OAuth 2.0 Client ID used for your web application.
*    - Under "Authorized JavaScript origins", add your domain (e.g., https://your-app-domain.com).
*    - Under "Authorized redirect URIs", add the URI from Firebase:
*      https://your-project-id.firebaseapp.com/__/auth/handler
*      (You can find this exact URI in your Firebase Console -> Authentication -> Google Sign-in details).
*
* By ensuring these four settings are correct, you will solve over 95% of Google Sign-In issues.
*/


// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = getAuth(app);
const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();
// Force account selection prompt for Google Sign-In for a more robust and predictable UX.
googleProvider.setCustomParameters({
  prompt: "select_account",
});


export { auth, db, googleProvider };