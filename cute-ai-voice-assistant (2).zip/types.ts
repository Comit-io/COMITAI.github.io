
export enum Screen {
  Voice,
  Chat,
  Home,
  AppDev,
  PromptMaker,
  Tools,
  Donation,
  VoiceGenerator,
  ImageGenerator,
  Admin,
  Settings,
  Login,
  Register,
  Profile,
  PromptLibrary,
  Dubbing,
  TermuxGuide
}

export interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  images?: string[];
}